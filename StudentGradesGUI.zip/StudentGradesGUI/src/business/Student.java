

package business;

import java.util.Arrays;

/**
 *
 * @author mahesh
 */
public class Student {

private double[] quiz = new double[6];
private double midt,prob,fie,qavg,cavg;
private String sid, lgrade,errmsg;


public Student(String sid,double[] score){
   

    for (int i=0; i<quiz.length;i++){
        this.quiz[i] = score[i];
    }
    this.midt=score[6];
    this.prob = score[7];
    this.fie= score[8];
    this.lgrade="";
    this.errmsg="";
    this.sid = sid;
    this.cavg=0;
    this.qavg=0;

    if(isValid()){
        calgrade();
    }

    
}    //end of constructor
    

    private boolean isValid() {

        boolean result = false;
        this.errmsg="";

           try {

              if (this.sid.isEmpty() ) {
                 this.errmsg += " Missing student ID ";
              } else if (!this.sid.substring(0,1).equals("A")) {
                  this.errmsg += " Student IDs must begin with an 'A' ";
              } else if (this.sid.length() != 9 ) {
                  this.errmsg +=
                         " 'A' must be followed by 8 digits. ";
              } else {
                  long id = Long.parseLong(this.sid.substring(1));
                  if (id <= 0 ) {
                      this.errmsg +=
                 " Numeric part must be positive number ";
                  }
                  result=true;
              }
           } catch (NumberFormatException e) {
              this.errmsg +=
                     " Illegal Number after 'A'not numeric. ";
           }

        for (int i=0;i<quiz.length;i++){
            if (quiz[i]<0 || quiz[i] > 125){
                this.errmsg += " Quiz " + (i+1) + " out of range.";
            }
        }

        if (midt<0 || midt>125){
            this.errmsg += " Midterm score  is out of range. ";
        }
        if (prob<0 || prob>125){
            this.errmsg += " Problem score is out of range.";
        }
        if (fie<0 || fie >125){
            errmsg += " Final exam score is out of range. ";

        }
       
        return result;
    }

    private void calgrade() {
        //this.errmsg="";

        Arrays.sort(this.quiz);

        
        this.qavg = (quiz[2] + quiz[3] + quiz[4] + quiz[5])/4.0;

        System.out.print(this.qavg);
        

        if (this.qavg >= 89.5 && this.midt >= 89.5 && this.prob >= 89.5) {
            cavg = (this.qavg + this.midt + this.prob) / 3.0;
            this.lgrade="A";
        } else {
            this.cavg = (this.qavg * .5) + (this.midt * .15) +
                    (this.prob * .1) + (this.fie * .25);
            if (this.cavg >= 89.5) {
                this.lgrade = "A";
            } else if (this.cavg >= 79.5) {
                this.lgrade = "B";
            } else if (this.cavg >= 69.5) {
                this.lgrade = "C";
            } else if (this.cavg >= 59.5) {
                this.lgrade = "D";
            } else {
                this.lgrade = "F";
            }
        }
        
    }

public String getErrorMsg(){
    return this.errmsg;
}

public double getQuiz(){

    return this.qavg;

}

public double getCourse(){
    return this.cavg;
}

public String getGrade(){
    return this.lgrade;
}

}//end of class
